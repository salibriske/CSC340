//
//  LinkedBag.h
//  ASMT 3 CSC 340
//
//  Created by Tommy Tran on 11/8/18.
//  Copyright © 2018 Tommy Tran. All rights reserved.
//

#pragma once
#include "Node.cpp"
#include "BagInterface.h"
#include <memory>

//
//
// PLEASE DO NOT CHANGE THIS FILE
//
//

template<typename ItemType>
class LinkedBag : public BagInterface<ItemType> {
    
    /*--------------------------CSC340-------------------------------------*/
public:
    bool removeSecondNode340();
    bool addEnd340(const ItemType&);
    int getCurrentSize340Iterative() const;
    int getCurrentSize340Recursive() const;
    int getCurrentSize340RecursiveNoHelper() const;
    int getFrequencyOf340Recursive(const ItemType&) const;
    int getFrequencyOf340RecursiveNoHelper(const ItemType&) const;
    ItemType removeRandom340();
private:
    //int getCurrentSize340RecursiveHelper(Node<ItemType>*) const; // if needed
    //int getFrequencyOf340RecursiveHelper(Node<ItemType>*, const ItemType&) const; // if needed
    int getCurrentSize340RecursiveHelper(std::shared_ptr<Node<ItemType>>) const;
    int getFrequencyOf340RecursiveHelper(std::shared_ptr<Node<ItemType>>, const ItemType&) const;
    
    /*----------------------------------------------------------------------*/
    
public:
    LinkedBag();
    LinkedBag(const LinkedBag<ItemType>&);
    virtual ~LinkedBag();
    int getCurrentSize() const;
    bool isEmpty() const;
    bool add(const ItemType&);
    bool remove(const ItemType&);
    void clear();
    bool contains(const ItemType&) const;
    int getFrequencyOf(const ItemType&) const;
    std::vector<ItemType> toVector() const;
    
private:
    //Node<ItemType>* headPtr{ nullptr }; // Pointer to first node
    std::shared_ptr<Node<ItemType>> headPtr{ nullptr };
    int itemCount{ 0 };                    // Current count of bag items
    
    // pointer to the node or the null pointer
    //Node<ItemType>* getPointerTo(const ItemType&) const;
    std::shared_ptr<Node<ItemType>> getPointerTo(const ItemType&) const;
};

