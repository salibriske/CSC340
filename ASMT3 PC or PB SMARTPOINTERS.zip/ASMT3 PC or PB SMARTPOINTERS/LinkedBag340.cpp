//
//  LinkedBag340.cpp
//  ASMT 3 CSC 340
//
//  Created by Tommy Tran on 11/8/18.
//  Copyright © 2018 Tommy Tran. All rights reserved.
//
#include <stdio.h>
#include <time.h>
#include "LinkedBag.cpp"
#include <memory>


template<typename ItemType>
bool LinkedBag<ItemType>::removeSecondNode340() {
    //Node<ItemType> *nodeToDeletePtr;
    std::shared_ptr<Node<ItemType>> nodeToDeletePtr;
    
    if(headPtr->getNext() != nullptr) {
        nodeToDeletePtr = headPtr->getNext();
        headPtr -> setNext(nodeToDeletePtr->getNext());
        nodeToDeletePtr->setNext(nullptr);
        //delete nodeToDeletePtr;
        nodeToDeletePtr.reset();
        itemCount--;
    }
    return true;
}



template<typename ItemType>
bool LinkedBag<ItemType>::addEnd340(const ItemType& newEntry) {
    //Node<ItemType>* newNodePtr = new Node<ItemType>();
    std::shared_ptr<Node<ItemType>> newNodePtr = make_shared<Node<ItemType>>();
    
    //Node<ItemType>* currPtr = headPtr;
    std::shared_ptr<Node<ItemType>>  currPtr = headPtr;
    
    
    while(currPtr->getNext() != nullptr) {
        currPtr = currPtr->getNext();
    }
    
    newNodePtr->setItem(newEntry);
    newNodePtr->setNext(nullptr);
    
    currPtr->setNext(newNodePtr);
    
    itemCount++;
    return true;
}


template<typename ItemType>
int LinkedBag<ItemType>::getCurrentSize340Iterative() const {
    //Node<ItemType>* currPtr = headPtr;
    std::shared_ptr<Node<ItemType>> currPtr = headPtr;
    int currSize = 1;
    
    while(currPtr->getNext() != nullptr) {
        currPtr = currPtr->getNext();
        currSize++;
    }
    
    return currSize;
}

template<typename ItemType>
//int LinkedBag<ItemType>::getCurrentSize340RecursiveHelper(Node<ItemType>* currPtr) const {
int LinkedBag<ItemType>::getCurrentSize340RecursiveHelper(std::shared_ptr<Node<ItemType>> currPtr) const {
    if (currPtr == nullptr)
        return 0;
    return 1 + getCurrentSize340RecursiveHelper(currPtr->getNext());
}


template<typename ItemType>
int LinkedBag<ItemType>::getCurrentSize340Recursive() const {
    return getCurrentSize340RecursiveHelper(headPtr);
}


template<typename ItemType>
int LinkedBag<ItemType>::getCurrentSize340RecursiveNoHelper() const {
    
    //static Node<ItemType>* currPtr = headPtr;
    static std::shared_ptr<Node<ItemType>>  currPtr = headPtr;
    
    if (currPtr == nullptr)
        return 0;
    else
    {
        currPtr = currPtr -> getNext();
        return 1 + getCurrentSize340RecursiveNoHelper();
    }
}


template<typename ItemType>
int LinkedBag<ItemType>::getFrequencyOf340RecursiveNoHelper(const ItemType& anEntry) const {
    static int frequency = 0;
    //static Node<ItemType>* currPtr = headPtr;
    static std::shared_ptr<Node<ItemType>>  currPtr = headPtr;
    static ItemType newEntry;
    
    if (newEntry != anEntry)
    {
        frequency = 0;
        newEntry = anEntry;
        currPtr = headPtr;
    }
    
    if (currPtr == nullptr)
        return frequency;
    
    if (anEntry == currPtr->getItem())
        frequency++;
    
    currPtr = currPtr -> getNext();
    return getFrequencyOf340RecursiveNoHelper(anEntry);
}


template<typename ItemType>
//int LinkedBag<ItemType>::getFrequencyOf340RecursiveHelper(Node<ItemType>* currPtr, const ItemType& anEntry) const
int LinkedBag<ItemType>::getFrequencyOf340RecursiveHelper(std::shared_ptr<Node<ItemType>> currPtr, const ItemType& anEntry) const
{
    static int frequency = 0;
    static ItemType newEntry;
    
    if (newEntry != anEntry)
    {
        frequency = 0;
        newEntry = anEntry;
        currPtr = headPtr;
    }
    
    if (currPtr == nullptr)
        return frequency;
    
    if (anEntry == currPtr->getItem())
        frequency++;
    return getFrequencyOf340RecursiveHelper(currPtr->getNext(), anEntry);
}


template<typename ItemType>
int LinkedBag<ItemType>::getFrequencyOf340Recursive(const ItemType& anEntry) const {
    return getFrequencyOf340RecursiveHelper(headPtr, anEntry);
}


template<typename ItemType>
ItemType LinkedBag<ItemType>::removeRandom340() {
    
    srand((unsigned) time(0));
    int randNum = (rand() % itemCount) + 1 ;
    
    //Node<ItemType>* prevPrevP = nullptr;
    //Node<ItemType>* prevP = nullptr;
    //Node<ItemType>* currP = headPtr;
    
    std::shared_ptr<Node<ItemType>> prevPrevP = nullptr;
    std::shared_ptr<Node<ItemType>> prevP = nullptr;
    std::shared_ptr<Node<ItemType>> currP = headPtr;
    
    ItemType delItemType = headPtr -> getItem();
    
    for (int i = 1; i <= itemCount; i++) {
        prevPrevP = prevP;
        prevP = currP;
        currP = currP -> getNext();
        
        if(randNum == i && i == 1)
        {
            headPtr = headPtr -> getNext();
            delItemType = prevP -> getItem();
            prevP -> setNext(nullptr);
            //delete prevP;
            prevP.reset();
            itemCount--;
            return delItemType;
        }
        
        if(randNum == i && i != itemCount)
        {
            delItemType = prevP -> getItem();
            prevPrevP -> setNext(prevP -> getNext());
            prevP -> setNext(nullptr);
            //delete prevP;
            prevP.reset();
            itemCount--;
            return delItemType;
        }
        
        else if(randNum == i && i == itemCount)
        {
            delItemType = prevP -> getItem();
            prevP -> setNext(nullptr);
            //delete currP;
            currP.reset();
            itemCount--;
            return delItemType;
        }
        
    }
    return delItemType;
}
