//
//  Include.h
//  ASMT 3 CSC 340
//
//  Created by Tommy Tran on 11/8/18.
//  Copyright © 2018 Tommy Tran. All rights reserved.
//

#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <memory>
#include "LinkedBag340.cpp"
#include "BagInterface.h"
#include "LinkedBag.h"
#include "Node.h"
using namespace std;
