//
//  Node.h
//  ASMT 3 CSC 340
//
//  Created by Tommy Tran on 11/8/18.
//  Copyright © 2018 Tommy Tran. All rights reserved.
//

#pragma once

//
//
// PLEASE DO NOT CHANGE THIS FILE
//
//

template<typename ItemType>
class Node {
public:
    Node();
    Node(const ItemType&);
    Node(const ItemType&, Node<ItemType>*);
    void setItem(const ItemType&);
    void setNext(Node<ItemType>*);
    ItemType getItem() const;
    Node<ItemType>* getNext() const;
    
private:
    ItemType        item;             // A data item
    Node<ItemType>* next{ nullptr }; // Pointer to next node
};
