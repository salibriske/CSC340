//
//  ASMT3 PA1.cpp
//  ASMT 3 CSC 340
//
//  Created by Tommy Tran on 11/8/18.
//  Copyright � 2018 Tommy Tran. All rights reserved.
//

#include <iostream>
using namespace std;
int main(){
	int *ptr = new int; // dynamically allocate an integer
	*ptr = 6; // put a value in that memory location

	delete ptr; // return the memory to the operating system.  ptr is now a dangling pointer.

	cout << *ptr; // Dereferencing a dangling pointer will cause undefined behavior
	delete ptr; // trying to deallocate the memory again will also lead to undefined behavior.

	return 0;
}