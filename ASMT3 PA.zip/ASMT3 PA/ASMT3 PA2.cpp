//
//  ASMT3 PA2.cpp
//  ASMT 3 CSC 340
//
//  Created by Tommy Tran on 11/8/18.
//  Copyright � 2018 Tommy Tran. All rights reserved.
//

#include <iostream>
using namespace std;
class Num {
public:
	Num() {}
	Num(int number) {
		this->number = new int(number);
	}
	~Num() {
		cout << *number << ": Destructor called." << endl;
		delete number;
	}
	const int* getNum() const {
		return this->number;
	}
private:
	int * number{ nullptr };
};

int main() {
	unique_ptr<Num> nine{ make_unique<Num>(9) };
	cout << "9, pointer: " << &nine << endl;
	cout << "9, address: " << addressof(*nine) << endl;
	cout << "9, object: " << nine.get() << endl << endl;

	unique_ptr<Num> two{ make_unique<Num>(2) };
	cout << "2, pointer: " << &two << endl;
	cout << "2, address: " << addressof(*two) << endl;
	cout << "2, object: " << two.get() << endl << endl;

	cout << "End of Program" << endl << endl;
	return 0;
}
/*
9, pointer: 0075F770
9, address: 007EA468
9, object: 007EA468

2, pointer: 0075F764
2, address: 007E0598
2, object: 007E0598

End of Program

2: Destructor called.
9: Destructor called.
*/