//
//  ASMT3 PA3.cpp
//  ASMT 3 CSC 340
//
//  Created by Tommy Tran on 11/8/18.
//  Copyright � 2018 Tommy Tran. All rights reserved.
//

#include <iostream>
using namespace std;
class Num {
public:
	Num() {}
	Num(int number) {
		this->number = new int(number);
	}
	~Num() {
		cout << *number << ": Destructor called." << endl;
		delete number;
	}
	const int* getNum() const {
		return this->number;
	}
private:
	int * number{ nullptr };
};

int main() {
	unique_ptr<Num> nine{ make_unique<Num>(9) };
	cout << "9, pointer: " << &nine << endl;
	cout << "9, address: " << addressof(*nine) << endl;
	cout << "9, object: " << nine.get() << endl << endl;

	nine.reset();
	cout << "9, pointer: " << &nine << endl;
	cout << "9, address: " << addressof(*nine) << endl;
	cout << "9, object: " << nine.get() << endl << endl;

	unique_ptr<Num> two{ make_unique<Num>(2) };
	cout << "2, pointer: " << &two << endl;
	cout << "2, address: " << addressof(*two) << endl;
	cout << "2, object: " << two.get() << endl << endl;

	two.reset();
	cout << "2, pointer: " << &two << endl;
	cout << "2, address: " << addressof(*two) << endl;
	cout << "2, object: " << two.get() << endl;

	cout << "End of Program" << endl << endl;
	return 0;
}
/*
9, pointer: 001DF86C
9, address: 005CA810
9, object: 005CA810

9: Destructor called.
9, pointer: 001DF86C
9, address: 00000000
9, object: 00000000

2, pointer: 001DF860
2, address: 005C9FD8
2, object: 005C9FD8

2: Destructor called.
2, pointer: 001DF860
2, address: 00000000
2, object: 00000000
End of Program
*/