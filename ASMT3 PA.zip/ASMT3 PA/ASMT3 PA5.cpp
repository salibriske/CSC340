//
//  ASMT3 PA5.cpp
//  ASMT 3 CSC 340
//
//  Created by Tommy Tran on 11/8/18.
//  Copyright � 2018 Tommy Tran. All rights reserved.
//

#include <iostream>
#include <string>
#include <memory>
#include <vector>
#include <typeinfo>
using namespace std;
class Num {
public:
	Num();
	Num(const int &);
	~Num();
	int getNum() const;
	void setNum(const int &);
private:
	int number{ 0 };
};

Num::Num() {}
Num::Num(const int & number) :number(number) {}
Num::~Num() {
	cout << "Num, Destructor: " << this << ", " << this->getNum() << endl;
}
int Num::getNum() const {
	return this->number;
}
void Num::setNum(const int& number) {
	this->number;
}
int main() {
	//dangling/stale pointer - raw ptr
	Num *id = new Num(9);
	Num *idPtr{ id };
	delete id;
	id = nullptr;
	cout << "idPtr points to: " << typeid(*idPtr).name() << endl;
	//cout << "idPtr points to: " << idPtr->getNum() << endl; //crash due to raw ptr

	//dangling/stale point - weak ptr
	//weak ptr helps make the code with being non-own
	shared_ptr<Num> six(new Num{ 6 });
	weak_ptr<Num> six_wptr{ six };
	cout << endl;
	cout << "six_wptr is dangling/stale: ";
	cout << (six_wptr.expired() ? "Yes" : "no") << endl;
	six.reset();
	cout << "six_wptr is dangling/stale: ";
	cout << (six_wptr.expired() ? "Yes" : "no") << endl;
}
/* output
Num, Destructor: 00B30568, 9
idPtr points to: class Num

six_wptr is dangling/stale: no
Num, Destructor: 00B35140, 6
six_wptr is dangling/stale: Yes
*/