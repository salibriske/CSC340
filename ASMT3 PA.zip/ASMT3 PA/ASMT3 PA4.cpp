//
//  ASMT3 PA4.cpp
//  ASMT 3 CSC 340
//
//  Created by Tommy Tran on 11/8/18.
//  Copyright � 2018 Tommy Tran. All rights reserved.
//

#include <iostream>
#include <typeinfo>
#include <string>
using namespace std;
int main() {
	unique_ptr<string> u_ptr(new string("object"));
	cout << "unique pointer" << endl;
	cout << "u_ptr.get(): " << u_ptr.get() << endl;
	cout << "*u_ptr = " << *u_ptr << endl;

	shared_ptr<string>  s_ptr(move(u_ptr));
	cout << "\nConvent unique to share" << endl;
	cout << "u_ptr.get(): " << u_ptr.get() << endl; //check unique
	cout << "s_ptr.get() = " << s_ptr.get() << endl;
	cout << "*s_ptr = " << *s_ptr << endl;
}
/*
unique pointer
u_ptr.get(): 00BC5768
*u_ptr = object

Convent unique to share
u_ptr.get(): 00000000
s_ptr.get() = 00BC5768
*s_ptr = object
*/